package com.example.section7configserver2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Section7Configserver2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
